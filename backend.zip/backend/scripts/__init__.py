# FarmWise Backend Scripts Package
